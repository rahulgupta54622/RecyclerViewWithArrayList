package com.example.rahul.arraylist1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Rahul on 30-01-2018.
 */

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {

    Context ctx;

   private ArrayList<Integer> myArrayList = new ArrayList<>();

    public MainAdapter(ArrayList<Integer> myArrayList,Context ctx) {

        this.myArrayList = myArrayList;
        this.ctx = ctx;
    }



    @Override
    public MainAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MainAdapter.ViewHolder holder, final int position)  {

       // data d = myArrayList.get(position);
       // String s = d.getName() + d.getNumber();

        holder.mTitle.setImageResource(myArrayList.get(position));

        final int CurrPos = position;

        holder.mTitle.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                Toast.makeText(ctx, "you longed pressed item no :" + position , Toast.LENGTH_SHORT).show();

                myArrayList.add(CurrPos);
                notifyItemInserted(CurrPos);
                return true;
            }
        });

        holder.mTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(ctx, "you clicked item no. :" + position , Toast.LENGTH_SHORT).show();

                Intent i = new Intent(ctx,ActivitySoccer.class);
                i.putExtra("faltu","position: " + position);
                ctx.startActivity(i);

            }
        });




    }

    @Override
    public int getItemCount() {
        return myArrayList.size();
    }

    

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView mTitle;




        public ViewHolder(View itemView) {
            super(itemView);
            mTitle = itemView.findViewById(R.id.title);

        }


        }
}