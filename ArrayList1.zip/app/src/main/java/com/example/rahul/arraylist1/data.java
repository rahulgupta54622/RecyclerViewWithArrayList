package com.example.rahul.arraylist1;

/**
 * Created by Rahul on 30-01-2018.
 */

public class data {

    String name;
    Integer number;

   // public data(String name, Integer number) {
      //  this.name = name;
   //     this.number = number;
  //  }

     public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
